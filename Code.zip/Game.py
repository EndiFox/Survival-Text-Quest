import random
import math 
import numpy as np

ingameminutes = 0
ingameseconds = 0

time_of_globe = str()
first = None
second = None
third = None
four = None

class player:
	health = 100
	hunger = 200
	mana = 10
	x = 0
	z = 0
	instrument = None
	inventory1 = [] 
	inventory2 = []
	inventory3 = []
	inventory4 = []
	inventorys = []
player = player()

class item:
	id = 0
	name = str()
	k = 0
	x = 0
	z = 0


class weaponbleed:
	x = 0
	z = 0
	damage = 0
	special1 = None
	special2 = None
	upgrade1 = False
	upgrade2 = False
	upgradechar = False
	char = None
	char2 = None
	id = 0
	name = str()
	usage = None

class weaponrange:
	x = 0
	z = 0
	throw = False
	bow = False
	gun = False
	damage = 0
	Vmagz = 0
	magz = 0
	magzhave = 0
	special1 = None
	special2 = None
	upgrade1 = False
	upgrade2 = False
	upgradechar = False
	char = None
	char2 = None
	id = 0
	name = str()
	usage = None

class weaponmagic:
	x = 0
	z = 0
	damage = 0
	manahave = 0
	book = False
	stick = False
	bigstick = False
	grimmuar = False
	dakaten = False
	bleed = False
	range = False
	special1 = None
	special2 = None
	upgrade1 = False
	upgrade2 = False
	upgradechar = False
	char = None
	char2 = None
	id = 0
	name = str()

class axe:
	x = 0
	z = 0
	aleb = False
	standart = False
	usage = None
	damage = 0
	manahave = 0
	id = 0
	name = str()
	level = 0
woodenaxe = axe()
woodenaxe.standart = True
woodenaxe.usage = 10
woodenaxe.id = 3
woodenaxe.name = "wooden axe"
class pickaxe:
	x = 0
	z = 0
	usage = None
	damage = 0
	manahave = 0
	id = 0
	name = str()
	level = 0

class Tree:
	wood = item()
	wood.name = "wood"
	wood.id = 1
	sapling = item()
	sapling.name = "sapling"
	sapling.id = 2
	posx = random.randint(1, 40)
	posz = random.randint(-40, 40)
	#posx = 2
	#posz = 0
	cutted = False
	
	stage = 0
	


Tree1 = Tree()
		
question = str()
x = 0
z = 0
x_preposition = x - 1
z_preposition = z - 1

#a = ([x = random.randint(-40, 40), y = random.randint(-40, 40)
#	  x = random.randint(-40, 40), y = random.randint(-40, 40)
#	  x = random.randint(-40, 40), y = random.randint(-40, 40)])

#maincode

exit = False

Tree1.intreetimer = random.randint(1, 120)
#print("timer="+str(Tree1.intreetimer))

if Tree1.intreetimer <= 30:
	Tree1.stage = 1
elif Tree1.intreetimer <= 60:
	Tree1.stage = 2
elif Tree1.intreetimer <= 90:
	Tree1.stage = 3 
elif Tree1.intreetimer <= 120:
	Tree1.stage = 4
#print("stage="+str(Tree1.stage))

while not exit:
	

# input user module
	
	a = input()

	if a == "n":
		exit = True
#up
	if player.x <= 40 and a == "w":
		player.x = player.x + 1
	
	if player.x > 40 and a == "w":
		print("This location is inDEV")
		player.x = player.x - 1	

#down	
	
	if player.x > 0 and player.x <= 40 and a == "s":
		player.x = player.x - 1
	
	if player.x < -20 and a == "s":
		print("This location is inDEV")
		player.x = player.x + 1

	if player.x <= 0 and player.x >= -20 and a == "s":
		print("dig")
		input()
		print("dig again")
		input()
		print("final")
		input()
		player.x = player.x - 1
	
	if player.x < -20 and a == "s":
		print("This location is inDEV")
		player.x = player.x + 1

#left	
	
	if player.z <= 0 and player.z >= -40 and a == "a" or player.z >= 0 and player.z <= 40 and a == "a":
		player.z = player.z - 1
		if player.z == -41:
			player.z = player.z - 1
	
	if player.x < 0 and player.x >= -20 and a == "a":
		print("dig")
		input()
		print("dig again")
		input()
		print("final")
		input()
		player.z = player.z - 1
#right
	
	if player.z >= 0 and player.z <= 40 and a == "d" or player.z <= 0 and player.z >= -40 and a == "d":
		player.z = player.z + 1
		if player.z == 41:
			player.z = player.z - 1
	
	if player.x < 0 and player.x >= -20 and a == "d":
		print("dig")
		input()
		print("dig again")
		input()
		print("final")
		input()
		player.z = player.z + 1

#checkuserposition	
	
	if a == "t":
		print( " Your Position on x: " + str(player.x)  + ";" + " Your Position on z: " + str(player.z) )

#timer	
	
	ingameseconds = ingameseconds + 1
	if ingameseconds >= 60:
		ingameminutes = ingameminutes + 1
		ingameseconds = 0
	if ingameminutes >= 60:
		ingameminutes = 0
	
	if ingameminutes <= 10:
		time_of_globe = "rise"
	if ingameminutes > 10 and ingameminutes <= 20:
		time_of_globe = "day"
	if ingameminutes > 20 and ingameminutes <= 40:
		time_of_globe = "dawn"
	if ingameminutes > 40 and ingameminutes <= 60:
		time_of_globe = "night"
	
	if a == "e":
		print(str(ingameminutes) + " : " + str(ingameseconds))
	if a == "q":
		print(time_of_globe)

#treesmechanics

	Tree1.intreetimer = Tree1.intreetimer + 1
	if Tree1.intreetimer > 120:
		Tree1.intreetimer = 120
	if Tree1.intreetimer <= 30:
		Tree1.stage = 1
	elif Tree1.intreetimer <= 60:
		Tree1.stage = 2
	elif Tree1.intreetimer <= 90:
		Tree1.stage = 3 
	elif Tree1.intreetimer <= 120:
		Tree1.stage = 4

	#print("timer="+str(Tree1.intreetimer))
	#print("stage="+str(Tree1.stage))

	
	if Tree1.stage == 4:
		Tree1.wood.k = 8
		Tree1.sapling.k = 2
	
	if Tree1.stage == 3:
		Tree1.wood.k = 6
		Tree1.sapling.k = 1
	
	if Tree1.stage == 2:
		Tree1.wood.k = 4
		Tree1.sapling.k = 0	
	
	if Tree1.stage == 1:
		Tree1.wood.k = 2
		Tree1.sapling.k = 0
		
	if Tree1.cutted == False and player.x == Tree1.posx and player.z == Tree1.posz:
		GlTreeX = Tree1.posx
		GlTreez = Tree1.posz
		#if player.x == Tree.posx and player.z == Tree.posz:
		question = input("You meet tree. Have you cut them? Y/N:")
		if question == "Y":
			print("cut")
			input()
			print("cut again")
			input()
			print("Au!")
			input()
			print("Hit!")
			input()
			print("I think this wasn't great idea...")
			input()
			print("Finish him!")
			input()
			Tree1.cutted = True

	if Tree1.cutted == True and player.x == Tree1.posx and player.z == Tree1.posz:
		question = input("On floor you see any items. Have you take it?Y/N")
		while question != "Y" and question != "N":
			question = input("On floor you see any items. Have you take it?Y/N")			
		if question == "Y":
			if Tree1.stage == 4:
				if player.inventory1 == []:
					player.inventory1.append(Tree1.wood.id)
					player.inventory1.append(Tree1.wood.k)
					player.inventory1.append(Tree1.wood.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.wood.id)
					player.inventory2.append(Tree1.wood.k)
					player.inventory2.append(Tree1.wood.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.wood.id)
					player.inventory3.append(Tree1.wood.k)
					player.inventory3.append(Tree1.wood.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.wood.id)
					player.inventory4.append(Tree1.wood.k)
					player.inventory4.append(Tree1.wood.name)
					#print(player.inventory4)
				
				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
					if question == "1":
						player.inventory1.clear
					if question == "2":
						player.inventory2.clear
					if question == "3":
						player.inventory3.clear
					if question == "4":
						player.inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						wood.x = x
						wood.y = y
				
				if player.inventory1 == []:
					player.inventory1.append(Tree1.sapling.id)
					player.inventory1.append(Tree1.sapling.k)
					player.inventory1.append(Tree1.sapling.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.sapling.id)
					player.inventory2.append(Tree1.sapling.k)
					player.inventory2.append(Tree1.sapling.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.sapling.id)
					player.inventory3.append(Tree1.sapling.k)
					player.inventory3.append(Tree1.sapling.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.sapling.id)
					player.inventory4.append(Tree1.sapling.k)
					player.inventory4.append(Tree1.sapling.name)
					#print(player.inventory4)
				

				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What you have to drop?(print 1-4 or N)")
					if question == "1":
						player.inventory1.clear
					if question == "2":
						player.inventory2.clear
					if question == "3":
						player.inventory3.clear
					if question == "4":
						player.inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						sapling.x = x
						sapling.y = y
			
			if Tree1.stage == 3:
				if player.inventory1 == []:
					player.inventory1.append(Tree1.wood.id)
					player.inventory1.append(Tree1.wood.k)
					player.inventory1.append(Tree1.wood.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.wood.id)
					player.inventory2.append(Tree1.wood.k)
					player.inventory2.append(Tree1.wood.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.wood.id)
					player.inventory3.append(Tree1.wood.k)
					player.inventory3.append(Tree1.wood.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.wood.id)
					player.inventory4.append(Tree1.wood.k)
					player.inventory4.append(Tree1.wood.name)
					#print(player.inventory4)
				
				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
					if question == "1":
						player.inventory1.clear
					if question == "2":
						player.inventory2.clear
					if question == "3":
						player.inventory3.clear
					if question == "4":
						player.inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						wood.x = x
						wood.y = y
				
				if player.inventory1 == []:
					player.inventory1.append(Tree1.sapling.id)
					player.inventory1.append(Tree1.sapling.k)
					player.inventory1.append(Tree1.sapling.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.sapling.id)
					player.inventory2.append(Tree1.sapling.k)
					player.inventory2.append(Tree1.sapling.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.sapling.id)
					player.inventory3.append(Tree1.sapling.k)
					player.inventory3.append(Tree1.sapling.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.sapling.id)
					player.inventory4.append(Tree1.sapling.k)
					player.inventory4.append(Tree1.sapling.name)
					#print(player.inventory4)
				

				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What you have to drop?(print 1-4 or N)")
					if question == "1":
						inventory1.clear
					if question == "2":
						inventory2.clear
					if question == "3":
						inventory3.clear
					if question == "4":
						inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						sapling.x = x
						sapling.y = y			
			
			if Tree1.stage == 2:
				if player.inventory1 == []:
					player.inventory1.append(Tree1.wood.id)
					player.inventory1.append(Tree1.wood.k)
					player.inventory1.append(Tree1.wood.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.wood.id)
					player.inventory2.append(Tree1.wood.k)
					player.inventory2.append(Tree1.wood.name)
					#print(player.inventory2)
					
				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.wood.id)
					player.inventory3.append(Tree1.wood.k)
					player.inventory3.append(Tree1.wood.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.wood.id)
					player.inventory4.append(Tree1.wood.k)
					player.inventory4.append(Tree1.wood.name)
					#print(player.inventory4)
				
				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
					if question == "1":
						player.inventory1.clear
					if question == "2":
						player.inventory2.clear
					if question == "3":
						player.inventory3.clear
					if question == "4":
						player.inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						wood.x = x
						wood.y = y
				
				if player.inventory1 == []:
					player.inventory1.append(Tree1.sapling.id)
					player.inventory1.append(Tree1.sapling.k)
					player.inventory1.append(Tree1.sapling.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.sapling.id)
					player.inventory2.append(Tree1.sapling.k)
					player.inventory2.append(Tree1.sapling.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.sapling.id)
					player.inventory3.append(Tree1.sapling.k)
					player.inventory3.append(Tree1.sapling.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.sapling.id)
					player.inventory4.append(Tree1.sapling.k)
					player.inventory4.append(Tree1.sapling.name)
					#print(player.inventory4)
				

				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What you have to drop?(print 1-4 or N)")
					if question == "1":
						inventory1.clear
					if question == "2":
						inventory2.clear
					if question == "3":
						inventory3.clear
					if question == "4":
						inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						sapling.x = x
						sapling.y = y			
			
			if Tree1.stage == 1:
				if player.inventory1 == []:
					player.inventory1.append(Tree1.wood.id)
					player.inventory1.append(Tree1.wood.k)
					player.inventory1.append(Tree1.wood.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.wood.id)
					player.inventory2.append(Tree1.wood.k)
					player.inventory2.append(Tree1.wood.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.wood.id)
					player.inventory3.append(Tree1.wood.k)
					player.inventory3.append(Tree1.wood.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.wood.id)
					player.inventory4.append(Tree1.wood.k)
					player.inventory4.append(Tree1.wood.name)
					#print(player.inventory4)
				
				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
					if question == "1":
						player.inventory1.clear
					if question == "2":
						player.inventory2.clear
					if question == "3":
						player.inventory3.clear
					if question == "4":
						player.inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						wood.x = x
						wood.y = y
				
				if player.inventory1 == []:
					player.inventory1.append(Tree1.sapling.id)
					player.inventory1.append(Tree1.sapling.k)
					player.inventory1.append(Tree1.sapling.name)
					#print(player.inventory1)
				
				elif (player.inventory1 != []) and (player.inventory2 == []):
					player.inventory2.append(Tree1.sapling.id)
					player.inventory2.append(Tree1.sapling.k)
					player.inventory2.append(Tree1.sapling.name)
					#print(player.inventory2)

				elif (player.inventory2 != []) and (player.inventory3 == []):
					player.inventory3.append(Tree1.sapling.id)
					player.inventory3.append(Tree1.sapling.k)
					player.inventory3.append(Tree1.sapling.name)
					#print(player.inventory3)

				elif (player.inventory3 != []) and (player.inventory4 == []):
					player.inventory4.append(Tree1.sapling.id)
					player.inventory4.append(Tree1.sapling.k)
					player.inventory4.append(Tree1.sapling.name)
					#print(player.inventory4)
				

				if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
					question = input("You Inventory is full! What you have to drop?(print 1-4 or N)")
					if question == "1":
						inventory1.clear
					if question == "2":
						inventory2.clear
					if question == "3":
						inventory3.clear
					if question == "4":
						inventory4.clear	
					if question == "N":
						print("Okay, i put it here.")
						sapling.x = x
						sapling.y = y
		#if Tree1.stage == 0:
		#	print("dvcbvcbcvbcvbcvb")
		if Tree1.cutted == True:
			Tree1.posx = random.randint(1, 40)
			Tree1.posz = random.randint(-40, 40)
			Tree1.cutted = False
	if question == "N":
			print("Let's search another place to hang out...")
			Tree1.cutted = False
	if a == "b":
		print(Tree1.posx, Tree1.posz)
	if a == "bs":
		print(Tree1.intreetimer)

#inventory organaiser
	
	if a == "i":
		print(player.inventory1, player.inventory2, player.inventory3, player.inventory4)
 
	
#stones
	
	stone = item()
	stone.id = 4
	stone.name = "stone"
	stone.x = random.randint(-40, 40)
	stone.z = random.randint(-40, 40)
	stone.k = 1
	
	stone1 = item()
	stone1.id = 4
	stone1.name = "stone"
	stone1.x = random.randint(-40, 40)
	stone1.z = random.randint(-40, 40)
	stone1.k = 1
	
	stone2 = item()
	stone2.id = 4
	stone2.name = "stone"
	stone2.x = random.randint(-40, 40)
	stone2.z = random.randint(-40, 40)
	stone2.k = 1
	
	stone3 = item()
	stone3.id = 4
	stone3.name = "stone"
	stone3.x = random.randint(-40, 40)
	stone3.z = random.randint(-40, 40)
	stone3.k = 1
	
	stone3 = item()
	stone3.id = 4
	stone3.name = "stone"
	stone3.x = random.randint(-40, 40)
	stone3.z = random.randint(-40, 40)
	stone3.k = 1
	
	stone4 = item()
	stone4.id = 4
	stone4.name = "stone"
	stone4.x = random.randint(-40, 40)
	stone4.z = random.randint(-40, 40)
	stone4.k = 1
	
	stone5 = item()
	stone5.id = 4
	stone5.name = "stone"
	stone5.x = random.randint(-40, 40)
	stone5.z = random.randint(-40, 40)
	stone5.k = 1
	
	stone6 = item()
	stone6.id = 4
	stone6.name = "stone"
	stone6.x = random.randint(-40, 40)
	stone6.z = random.randint(-40, 40)
	stone6.k = 1
	
	stone7 = item()
	stone7.id = 4
	stone7.name = "stone"
	stone7.x = random.randint(-40, 40)
	stone7.z = random.randint(-40, 40)
	stone7.k = 1
	
	stone8 = item()
	stone8.id = 4
	stone8.name = "stone"
	stone8.x = random.randint(-40, 40)
	stone8.z = random.randint(-40, 40)
	stone8.k = 1
	
	stone9 = item()
	stone9.id = 4
	stone9.name = "stone"
	stone9.x = random.randint(-40, 40)
	stone9.z = random.randint(-40, 40)
	stone9.k = 1
	
	stone10 = item()
	stone10.id = 4
	stone10.name = "stone"
	stone10.x = random.randint(-40, 40)
	stone10.z = random.randint(-40, 40)
	stone10.k = 1
	
	if player.x == stone.x and player.z == stone.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":
					if player.inventory1 == []:
						player.inventory1.append(stone.id)
						player.inventory1.append(stone.k)
						player.inventory1.append(stone.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone.id)
						player.inventory2.append(stone.k)
						player.inventory2.append(stone.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone.id)
						player.inventory3.append(stone.k)
						player.inventory3.append(stone.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone.id)
						player.inventory4.append(stone.k)
						player.inventory4.append(stone.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone.x = x
							stone.y = y
	
	if player.x == stone1.x and player.z == stone1.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone1.id)
						player.inventory1.append(stone1.k)
						player.inventory1.append(stone1.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone1.id)
						player.inventory2.append(stone1.k)
						player.inventory2.append(stone1.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone1.id)
						player.inventory3.append(stone1.k)
						player.inventory3.append(stone1.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone1.id)
						player.inventory4.append(stone1.k)
						player.inventory4.append(stone1.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone1.x = x
							stone1.y = y

	if player.x == stone2.x and player.z == stone2.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone2.id)
						player.inventory1.append(stone2.k)
						player.inventory1.append(stone2.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone2.id)
						player.inventory2.append(stone2.k)
						player.inventory2.append(stone2.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone2.id)
						player.inventory3.append(stone2.k)
						player.inventory3.append(stone2.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone2.id)
						player.inventory4.append(stone2.k)
						player.inventory4.append(stone2.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone2.x = x
							stone2.y = y	

	if player.x == stone3.x and player.z == stone3.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone3.id)
						player.inventory1.append(stone3.k)
						player.inventory1.append(stone3.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone3.id)
						player.inventory2.append(stone3.k)
						player.inventory2.append(stone3.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone3.id)
						player.inventory3.append(stone3.k)
						player.inventory3.append(stone3.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone3.id)
						player.inventory4.append(stone3.k)
						player.inventory4.append(stone3.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone3.x = x
							stone3.y = y							
	
	if player.x == stone4.x and player.z == stone4.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone4.id)
						player.inventory1.append(stone4.k)
						player.inventory1.append(stone4.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone4.id)
						player.inventory2.append(stone4.k)
						player.inventory2.append(stone4.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone4.id)
						player.inventory3.append(stone4.k)
						player.inventory3.append(stone4.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone4.id)
						player.inventory4.append(stone4.k)
						player.inventory4.append(stone4.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone4.x = x
							stone4.y = y
	
	if player.x == stone5.x and player.z == stone5.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone5.id)
						player.inventory1.append(stone5.k)
						player.inventory1.append(stone5.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone5.id)
						player.inventory2.append(stone5.k)
						player.inventory2.append(stone5.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone5.id)
						player.inventory3.append(stone5.k)
						player.inventory3.append(stone5.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone5.id)
						player.inventory4.append(stone5.k)
						player.inventory4.append(stone5.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone5.x = x
							stone5.y = y	
	
	if player.x == stone5.x and player.z == stone5.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone6.id)
						player.inventory1.append(stone6.k)
						player.inventory1.append(stone6.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone6.id)
						player.inventory2.append(stone6.k)
						player.inventory2.append(stone6.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone6.id)
						player.inventory3.append(stone6.k)
						player.inventory3.append(stone6.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone6.id)
						player.inventory4.append(stone6.k)
						player.inventory4.append(stone6.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone6.x = x
							stone6.y = y	
	
	if player.x == stone7.x and player.z == stone7.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone7.id)
						player.inventory1.append(stone7.k)
						player.inventory1.append(stone7.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone7.id)
						player.inventory2.append(stone7.k)
						player.inventory2.append(stone7.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone7.id)
						player.inventory3.append(stone7.k)
						player.inventory3.append(stone7.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone7.id)
						player.inventory4.append(stone7.k)
						player.inventory4.append(stone7.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone7.x = x
							stone7.y = y
	
	if player.x == stone8.x and player.z == stone8.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone8.id)
						player.inventory1.append(stone8.k)
						player.inventory1.append(stone8.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone8.id)
						player.inventory2.append(stone8.k)
						player.inventory2.append(stone8.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone8.id)
						player.inventory3.append(stone8.k)
						player.inventory3.append(stone8.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone8.id)
						player.inventory4.append(stone8.k)
						player.inventory4.append(stone8.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone8.x = x
							stone8.y = y
		
	if player.x == stone9.x and player.z == stone9.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone9.id)
						player.inventory1.append(stone9.k)
						player.inventory1.append(stone9.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone9.id)
						player.inventory2.append(stone9.k)
						player.inventory2.append(stone9.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone9.id)
						player.inventory3.append(stone9.k)
						player.inventory3.append(stone9.name)
					#print(player.inventory3)

					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone9.id)
						player.inventory4.append(stone9.k)
						player.inventory4.append(stone9.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone9.x = x
							stone9.y = y
							
	if player.x == stone10.x and player.z == stone10.z:
			question = input("On floor you see any items. Have you take it?Y/N")
			while question != "Y" and question != "N":
				question = input("On floor you see any items. Have you take it?Y/N")			
			if question == "Y":	
					if player.inventory1 == []:
						player.inventory1.append(stone10.id)
						player.inventory1.append(stone10.k)
						player.inventory1.append(stone10.name)
					#print(item.name)
					#print(Tree1.sapling.name)
					#print(Tree1.wood.name)
					#print(player.inventory1)
				
					elif (player.inventory1 != []) and (player.inventory2 == []):
						player.inventory2.append(stone10.id)
						player.inventory2.append(stone10.k)
						player.inventory2.append(stone10.name)
					#print(player.inventory2)

					elif (player.inventory2 != []) and (player.inventory3 == []):
						player.inventory3.append(stone10.id)
						player.inventory3.append(stone10.k)
						player.inventory3.append(stone10.name)
					#print(player.inventory3)
	
					elif (player.inventory3 != []) and (player.inventory4 == []):
						player.inventory4.append(stone10.id)
						player.inventory4.append(stone10.k)
						player.inventory4.append(stone10.name)
					#print(player.inventory4)
				
					if (player.inventory1 != []) and (player.inventory2 != []) and (player.inventory3 != []) and (player.inventory4 != []):
						question = input("You Inventory is full! What do you have to drop?(print 1-4 or N)")
						if question == "1":
							player.inventory1.clear
						if question == "2":
							player.inventory2.clear
						if question == "3":
							player.inventory3.clear
						if question == "4":
							player.inventory4.clear	
						if question == "N":
							print("Okay, i put it here.")
							stone10.x = x
							stone10.y = y	

#craft system and recipes

#wooden axe	
	
	#if a == "cr":
	#	first = input("Select first slot(1-4)(for skiping print n:")
	#	if (first == "n") or (first == "1") or (first == "2") or (first == "3") or (first == "4"):
	#		second = input("Select first slot(1-4)(for skiping print n:")
	#		if (second == "n") or (second == "1") or (second == "2") or (second == "3") or (second == "4"):
	#			third = input("Select first slot(1-4)(for skiping print n:")
	#			if (third == "n") or (third == "1") or (third == "2") or (third == "3") or (third == "4"):
	#				four = input("Select first slot(1-4)(for skiping print n:")
	#				if (four == "n") or (four == "1") or (four == "2") or (four == "3") or (four == "4"):
	#					if (first == wood) or (second == wood) or (third == wood) or (four == wood):
	#						if (first == stone) or (second == stone) or (third == stone) or

#helpmanual
	
	if a == "h":
			print("##################---HELP---##################\n --Version--\n Alfa-0.2.0\n --credits--\n EndiFox - Developer\n\n ---MOVEMENT--\n w - up\n a - left\n s - down\n d - Right\n t - show my position\n e - show in-game time\n q - show time of day\n h - show this manual\n If you position is on 0 or lower 0 for X, you need press any button.\n ALERT! IN THIS VERSION YOU CANT SAVE GAME!\n##################---HELP---##################")
